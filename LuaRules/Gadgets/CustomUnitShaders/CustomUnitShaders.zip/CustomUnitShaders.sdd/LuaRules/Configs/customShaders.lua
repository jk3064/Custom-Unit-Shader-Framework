-- $Id$
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local materialDefs = {
   copyEngineS3o = {
      shader = include("LuaRules/Configs/UnitShaders/default.lua"),
      usecamera   = false,
      culling     = GL.BACK,
      texunits    = {
        [0] = '%UnitDefID:0',
        [1] = '%UnitDefID:1',
        [2] = '$shadow',
        [3] = '$specular',
        [4] = '$reflection',
      },
   },
   normalMappedS3o = {
      shaderDefinitions = {
        "#define use_normalmapping",
      },
      shader = include("LuaRules/Configs/UnitShaders/default.lua"),
      usecamera   = false,
      culling     = GL.BACK,
      texunits    = {
        [0] = '%UnitDefID:0',
        [1] = '%UnitDefID:1',
        [2] = '$shadow',
        [3] = '$specular',
        [4] = '$reflection',
        [5] = 'unittextures/spherebot_normals.tga',
      },
   },
   shark = {
      shader = include("LuaRules/Configs/UnitShaders/shark.lua"),
      usecamera   = false,
      culling     = GL.BACK,
      texunits    = {
        [0] = '%UnitDefID:0',
        [1] = '%UnitDefID:1',
        [2] = '$shadow',
        [3] = '$specular',
        [4] = '$reflection',
      },
      predl  = nil,
      postdl = nil,
      DrawUnit = include("LuaRules/Configs/UnitShaders/shark_update.lua"),
   }
}

local unitShaderDefs = {
   armwar = "normalMappedS3o",
   armpw = "normalMappedS3o",
   angelshark = "shark",
}


return materialDefs, unitShaderDefs


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
