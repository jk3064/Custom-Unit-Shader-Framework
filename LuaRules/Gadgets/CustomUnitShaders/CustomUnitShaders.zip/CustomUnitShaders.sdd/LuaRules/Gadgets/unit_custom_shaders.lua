-- $Id$
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  author:  jK
--
--  Copyright (C) 2008,2009,2010.
--  Licensed under the terms of the GNU GPL, v2 or later.
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

function gadget:GetInfo()
  return {
    name      = "UnitCustomShaders",
    desc      = "allows to override the engine unit shader",
    author    = "jK",
    date      = "2008,2009,2010",
    license   = "GNU GPL, v2 or later",
    layer     = 1,
    enabled   = true  --  loaded by default?
  }
end

if (gadgetHandler:IsSyncedCode()) then

  function gadget:UnitCreated(unitID,unitDefID,teamID)
     SendToUnsynced("unitshaders_created", unitID, unitDefID,teamID)
  end

  function gadget:UnitDestroyed(unitID,unitDefID,teamID)
     SendToUnsynced("unitshaders_destroyed", unitID, unitDefID,teamID)
  end

  function gadget:GameFrame()
    for i,uid in ipairs(Spring.GetAllUnits()) do
      gadget:UnitCreated(uid,Spring.GetUnitDefID(uid),Spring.GetUnitTeam(uid))
    end
    gadgetHandler:RemoveCallIn('GameFrame')
  end

  return
end

if (not gl.CreateShader) then
  return false
end

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local drawUnitList = {}
local unitMaterials,bufMaterials = {},{},{}

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

function GetUnitMaterial(unitDefID)
  local mat = bufMaterials[unitDefID]
  if (mat) then
    return mat
  end

  local mat = unitMaterials[unitDefID]

  --// find unitdef tex keyword and replace it
  --// (a shader can be just for multiple unitdefs, so we support this keywords)
  local texUnits = {}
  for texid,tex in pairs(mat.texunits or {}) do
    if (tex == "%UnitDefID:0") then
      tex = '%'..unitDefID..':0'
    elseif (tex == "%UnitDefID:1") then
      tex = '%'..unitDefID..':1'
    end
    texUnits[texid] = tex
  end

  local luaMat = Spring.UnitRendering.GetMaterial("opaque",{
                   shader          = mat.shader,
                   cameraposloc    = mat.cameraPosLoc,
                   cameraloc       = mat.cameraLoc,
                   camerainvloc    = mat.cameraInvLoc,
                   shadowloc       = mat.shadowMatrixLoc,
                   shadowparamsloc = mat.shadowParamsLoc,
                   usecamera       = mat.usecamera,
                   culling         = mat.culling,
                   texunits        = texUnits,
                   prelist         = mat.predl,
                   postlist        = mat.postdl,
                 })

  bufMaterials[unitDefID] = luaMat

  return luaMat
end


function UnitCreated(_,unitID,unitDefID,teamID)
  if (unitMaterials[unitDefID]) then
    Spring.UnitRendering.SetLODCount(unitID,0)
    Spring.UnitRendering.SetLODCount(unitID,1)
    Spring.UnitRendering.SetLODLength(unitID,1,0.2)
    Spring.UnitRendering.SetMaterialLastLOD(unitID, "opaque", 1)
    Spring.UnitRendering.SetMaterial(unitID,1,"opaque",GetUnitMaterial(unitDefID))
    for i=1,100 do
      Spring.UnitRendering.SetPieceList(unitID, 1, i)
    end

    local mat = unitMaterials[unitDefID]
    if (mat.DrawUnit) then
      Spring.UnitRendering.SetUnitLuaDraw(unitID,true)
      drawUnitList[unitID] = mat
    end
  end
end


function UnitDestroyed(_,unitID)
  drawUnitList[unitID] = nil
end


function gadget:DrawUnit(unitID)
  local mat = drawUnitList[unitID]
  if (mat) then
    return mat.DrawUnit(unitID, mat)
  end
end


function gadget:Initialize()
  local materialDefs,unitNameDef = include("LuaRules/Configs/customShaders.lua")

  for materialName,material in pairs(materialDefs) do
    if (material.shader)and
       (material.shader ~= "3do")and(material.shader ~= "s3o")
    then
      --// append definitions at top of the shader code
      --// (this way we can modularize a shader and enable/disable features in it)
      if (material.shaderDefinitions) then
        local definitions = table.concat(material.shaderDefinitions, "\n")
        if (material.shader.vertex)
          then material.shader.vertex = definitions .. material.shader.vertex; end
        if (material.shader.fragment)
          then material.shader.fragment = definitions .. material.shader.fragment; end
        if (material.shader.geometry)
          then material.shader.geometry = definitions .. material.shader.geometry; end
      end

      local GLSLshader = gl.CreateShader(material.shader)
      Spring.Echo(gl.GetShaderLog())

      if (GLSLshader) then
        material.shader          = GLSLshader
        material.cameraLoc       = gl.GetUniformLocation(GLSLshader,"camera")
        material.cameraInvLoc    = gl.GetUniformLocation(GLSLshader,"cameraInv")
        material.cameraPosLoc    = gl.GetUniformLocation(GLSLshader,"cameraPos")
        material.sunLoc          = gl.GetUniformLocation(GLSLshader,"sunPos")
        material.shadowMatrixLoc = gl.GetUniformLocation(GLSLshader,"shadowMatrix")
        material.shadowParamsLoc = gl.GetUniformLocation(GLSLshader,"shadowParams")
        material.frameLoc        = gl.GetUniformLocation(GLSLshader,"frame2")
        material.speedLoc        = gl.GetUniformLocation(GLSLshader,"speed")
      end
    end

    if (material.texunits) then
      local texdl = gl.CreateList(function()
      for i=1,#material.texunits do
        local prefix = material.texunits[i]:sub(1,1)
        if   (prefix~="%") 
          and(prefix~="#")
          and(prefix~="!")
          and(prefix~="$")
        then
          gl.Texture(material.texunits[i])
        end
      end
      end)
      gl.DeleteList(texdl)
    end
  end


  for unitName,materialName in pairs(unitNameDef) do
    unitMaterials[UnitDefNames[unitName].id or -1] = materialDefs[materialName]
  end

  gadgetHandler:AddSyncAction("unitshaders_created", UnitCreated)
  gadgetHandler:AddSyncAction("unitshaders_destroyed", UnitDestroyed)
end