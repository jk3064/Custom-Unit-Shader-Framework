-- $Id: messages.lua 3064 2008-10-20 02:05:50Z det $
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  file:    messages.lua
--  brief:   messages definitions
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local messages = {
	--Kaine
	"Team%i (%s) discovered the meaning of life.",
	"Team%i (%s) should have considered early retirement.",
	"Team%i (%s) has been an inspiration to us all.",
	"Team%i (%s) forgot to wear clean underwear.",
	"Team%i (%s) has been completely annihilated.",
	"Team%i (%s) must have been a porcer.",
	"Team%i (%s) wasn't nice to the other kids.",
	"Team%i (%s) was beamed up by the aliens.",
	"Team%i (%s) partied like a rock star.",
	"Team%i (%s) had a power outage of catastrophic proportions.",
	"Team%i (%s) HAS JUST WON THE JACKPOT OF DEATH MESSAGE #200! CONGRADULATIONS!",
}

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

return messages

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
